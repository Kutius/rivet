@echo off
echo Hello from Rivet 1.1!
echo args: %*

