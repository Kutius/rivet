@echo off
echo Hello from Rivet!
echo args: %*

